#include "velocity.h"


// Put your velocity methods here
Velocity :: Velocity() {
	setDx(0);
	setDy(0);
}