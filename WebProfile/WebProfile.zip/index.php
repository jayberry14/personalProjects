<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Mayberry - Portfolio</title>
    <link rel="icon" type="image/ico" href="https://cdn3.iconfinder.com/data/icons/round-icons-vol-2/512/j-512.png">
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel='stylesheet' type='text/css' media='screen' href='directory.css'>
    <script>
        if ( window.history.replaceState ) {
            window.history.replaceState( null, null, window.location.href );
        }
    </script>
</head>
<body>
    <?php include 'header.php';?>
    <h1>Joshua Mayberry - Portfolio</h1>
    <div class="container-fluid bg-1 text-center">
        
    </div>
    <div class="container-fluid bg-1">
        <p>
            
        </p>
    </div>
    <div class="container-fluid bg-2">
        <p>
            
        </p>
    </div>
    <div class="container-fluid bg-3">
        <p>
            
        </p>
    </div>
    <div class="container-fluid bg-4">
        <p>
            
        </p>
    </div>
    <div class="container-fluid bg-5">
        <p>
            
        </p>
    </div>
    <div class="container-fluid bg-6">
        <p>
            
        </p>
    </div>
</body>
</html>

