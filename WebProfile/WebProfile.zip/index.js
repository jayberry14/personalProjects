function navigate(button) {
    var URL;
    if (button == assignmentsBut) {
        URL = "assingments.php";
    }
    else if (button == aboutBut) {
        URL = "index.php";
    }
    <a href="URL"></a>
}